package onlinefooddelivery.OnlineFoodDelivery.Entity;

import java.time.LocalDateTime;

import jakarta.annotation.Nullable;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

@Entity 
@Table(name="`Orders`")
public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;	
	@NotEmpty
	private String menuNames;
	@NotNull 
	private LocalDateTime orderDateTime;
    @Nullable
    private Double totalPrice;
    @Nullable
    private String paymentMethod;	
	@ManyToOne
	@JoinColumn(name ="user_id")
	private User user;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getMenuNames() {
		return menuNames;
	}
	public void setMenuNames(String menuNames) {
		this.menuNames = menuNames;
	}
	public LocalDateTime getOrderDateTime() {
		return orderDateTime;
	}
	public void setOrderDateTime(LocalDateTime orderDateTime) {
		this.orderDateTime = orderDateTime;
	}
	public Double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Order(Long id, @NotEmpty String menuNames, @NotNull LocalDateTime orderDateTime, Double totalPrice,
			String paymentMethod, User user) {
		super();
		this.id = id;
		this.menuNames = menuNames;
		this.orderDateTime = orderDateTime;
		this.totalPrice = totalPrice;
		this.paymentMethod = paymentMethod;
		this.user = user;
	}
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Order [id=" + id + ", menuNames=" + menuNames + ", orderDateTime=" + orderDateTime + ", totalPrice="
				+ totalPrice + ", paymentMethod=" + paymentMethod + ", user=" + user + "]";
	}

	

	
}
