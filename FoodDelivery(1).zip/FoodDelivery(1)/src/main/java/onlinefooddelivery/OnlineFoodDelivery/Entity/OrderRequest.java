package onlinefooddelivery.OnlineFoodDelivery.Entity;

import java.util.List;

public class OrderRequest {
    private List<Long> menuItemIds;
    private String paymentMethod;
    
	public List<Long> getMenuItemIds() {
		return menuItemIds;
	}
	public void setMenuItemIds(List<Long> menuItemIds) {
		this.menuItemIds = menuItemIds;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
     
     


}
