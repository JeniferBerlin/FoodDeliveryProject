package onlinefooddelivery.OnlineFoodDelivery.Service;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import onlinefooddelivery.OnlineFoodDelivery.DAO.MenuItemDAO;
import onlinefooddelivery.OnlineFoodDelivery.DAO.RestaurantDAO;
import onlinefooddelivery.OnlineFoodDelivery.Entity.MenuItem;
import onlinefooddelivery.OnlineFoodDelivery.Entity.Restaurant;
@Service 
public class MenuItemService {
	@Autowired 
	private MenuItemDAO menuItemdao;
	@Autowired private RestaurantDAO restaurantDAO;


	public List<MenuItem> findByRestaurantId(Long restaurantId) {
		
		return menuItemdao.findByRestaurantId(restaurantId);
	}

    //@Transactional
	public MenuItem saveMenuItem(MenuItem menuItem) {
		//menuItem.setId(null);
		Restaurant savedRestaurant = restaurantDAO.save(menuItem.getRestaurant()); // Save restaurant first
		menuItem.setRestaurant(savedRestaurant); // Set the saved restaurant
		
		return menuItemdao.save(menuItem);
	}
	
	


	public MenuItem updateMenuItem(MenuItem menuItem) {
		menuItemdao.findById(menuItem.getId()).orElseThrow(null);
		return menuItemdao.save(menuItem);
	}


	public void deleteMenuItem(Long id) {
		menuItemdao.deleteById(id);
		
	}

	public List<MenuItem> getmenuItems() {
		List<MenuItem> menuItems=new ArrayList<MenuItem>();
		menuItemdao.findAll().forEach(menuItems::add);
		return menuItems;
	}
	

}
