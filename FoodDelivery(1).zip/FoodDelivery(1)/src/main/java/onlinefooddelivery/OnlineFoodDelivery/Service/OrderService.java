package onlinefooddelivery.OnlineFoodDelivery.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import onlinefooddelivery.OnlineFoodDelivery.DAO.MenuItemDAO;
import onlinefooddelivery.OnlineFoodDelivery.DAO.OrderDAO;
import onlinefooddelivery.OnlineFoodDelivery.DAO.UserDAO;
import onlinefooddelivery.OnlineFoodDelivery.Entity.MenuItem;
import onlinefooddelivery.OnlineFoodDelivery.Entity.Order;
import onlinefooddelivery.OnlineFoodDelivery.Entity.OrderRequest;
import onlinefooddelivery.OnlineFoodDelivery.Entity.User;
@Service 
public class OrderService {
	@Autowired 
	private OrderDAO orderdao;
	@Autowired  private UserDAO userdao;
	@Autowired private MenuItemDAO menuItemdao;
	

	 public Order save(Order order) {
	        return orderdao.save(order);  // Save order to the database
	    }

	public List<Order> findByUserId(Long userId) {
		
		return orderdao.findByUserId(userId);
	}

	public void placeOrder(Long userId, OrderRequest orderRequest) {
		User user = userdao.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

		List<MenuItem> menuItems = menuItemdao.findAllById(orderRequest.getMenuItemIds());

        double totalPrice = menuItems.stream().mapToDouble(MenuItem::getPrice).sum();

        String menuNames = menuItems.stream()
                     .map(MenuItem::getName)
                     .collect(Collectors.joining(", "));

        Order order = new Order();
        order.setUser(user);
        order.setMenuNames(menuNames);
        order.setTotalPrice(totalPrice);
        order.setPaymentMethod(orderRequest.getPaymentMethod());
        order.setOrderDateTime(LocalDateTime.now());
        orderdao.save(order);
}
}
	

