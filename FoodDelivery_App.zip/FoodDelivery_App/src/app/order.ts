export interface Order {
    id?: number;
    orderDateTime?: string;
    totalPrice?: number;
    paymentMethod: string;
    userId?: number;
    name: string;
    address: string;
    mobileno: number;  
    
}
