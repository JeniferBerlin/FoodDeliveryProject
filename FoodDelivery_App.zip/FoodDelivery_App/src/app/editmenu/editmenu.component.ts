import { Component } from '@angular/core';
import { Menu } from '../menu';
import { MenuService } from '../menu-service';
import Swal from 'sweetalert2';
import { RestaurantService } from '../restaurant.service';



@Component({
  selector: 'app-editmenu',
  standalone: false,
  templateUrl: './editmenu.component.html',
  styleUrl: './editmenu.component.css'
})
export class EditmenuComponent {
  menuItems: Menu[] = []; // Array to hold fetched menu items
  editableMenu: Menu | null = null; // Store the menu item being edited

  constructor(private menuService: MenuService) {}

  ngOnInit(): void {
    this.loadMenuItems();
  }

  // Fetch menu items from backend
  loadMenuItems(): void {
    this.menuService.getMenu().subscribe(
      (data) => {
        this.menuItems = data; // Bind data to the menuItems array
        console.log('Menu items fetched successfully:', data);
      },
      (error) => {
        console.error('Error fetching menu items:', error);
      }
    );
  }

  // Start editing the selected menu item
  editMenu(menu: Menu): void {
    this.editableMenu = { ...menu }; // Clone the menu item to prevent direct modification
  }

  // Cancel the editing
  cancelEdit(): void {
    this.editableMenu = null; // Reset editableMenu
  }

  // Save the edited menu item
  saveMenu(menu: Menu): void {
    this.menuService.updateMenus(menu.id).subscribe(
      (updatedMenu) => {
        const index = this.menuItems.findIndex(m => m.id === updatedMenu.id);
        if (index !== -1) {
          this.menuItems[index] = updatedMenu;
        }
        this.editableMenu = null;
        console.log('Menu item updated successfully:', updatedMenu);
        alert('Menu item updated successfully!');
      },
      (error) => {
        console.error('Error updating menu item:', error);
        alert('Failed to update menu item. Please try again later.');
      }
    );
  }

//   deleteMenu(id:number):void
// {
//   this.menuService.deletemenu(id).subscribe(()=>{
//     this.loadMenuItems();
//   });
// }
  // Delete a menu item
  deleteMenu(menuId: number): void {
    if (confirm('Are you sure you want to delete this menu item?')) {
      this.menuService.deleteMenu(menuId).subscribe(
        () => {
          this.menuItems = this.menuItems.filter(m => m.id !== menuId);
          console.log('Menu item deleted successfully');
        },
        (error) => {
          
          console.error('Error deleting menu item:', error);
        }
      );
    }
  }
  
 
 
  }

 
