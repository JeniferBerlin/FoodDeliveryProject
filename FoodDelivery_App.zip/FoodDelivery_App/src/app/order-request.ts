export interface OrderRequest {
    menuItemIds: number[];
    paymentMethod: string;
}
